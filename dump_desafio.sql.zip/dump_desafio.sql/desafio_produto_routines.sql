CREATE DATABASE  IF NOT EXISTS `desafio_produto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `desafio_produto`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: desafio_produto
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'desafio_produto'
--

--
-- Dumping routines for database 'desafio_produto'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_consulta_pedidos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_consulta_pedidos`(
    IN p_valor_minimo DECIMAL(10,2),
    IN p_status VARCHAR(50)
)
BEGIN
    SELECT 
        c.nm_cliente AS nome_cliente, 
        p.id_pedido  AS id_pedido, 
        p.vl_pedido  AS valor_total
    FROM 
        pedido p
    INNER JOIN 
        cliente c ON p.id_cliente = c.id_cliente
    INNER JOIN 
        (
            SELECT sp1.id_pedido, sp1.id_status
            FROM status_pedido sp1
            INNER JOIN (
                SELECT id_pedido, MAX(dt_status) AS ultima_data
                FROM status_pedido
                GROUP BY id_pedido
            ) sp2 ON sp1.id_pedido = sp2.id_pedido AND sp1.dt_status = sp2.ultima_data
        ) ult_status ON ult_status.id_pedido = p.id_pedido
    WHERE 
        ult_status.id_status = p_status
        AND p.vl_pedido > p_valor_minimo
    ORDER BY 
        p.dt_pedido DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_relatorio_vendas_periodo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_relatorio_vendas_periodo`(
    IN data_inicio DATE,
    IN data_fim DATE,
    IN categoria_produto VARCHAR(100)
)
BEGIN
    CREATE TEMPORARY TABLE tmp_relatorio_vendas (
        tipo_linha VARCHAR(20),           -- 'Resumo' ou 'Produto'
        descricao VARCHAR(200),
        quantidade INT,
        valor DECIMAL(15,2)
    );

    INSERT INTO tmp_relatorio_vendas (tipo_linha, descricao, quantidade, valor)
    SELECT 
        'Resumo', 
        'Quantidade/Soma Total de Pedidos', 
        COUNT(DISTINCT p.id_pedido), 
        COALESCE(SUM(p.vl_pedido), 0)
    FROM 
        pedido p
    WHERE 
        p.dt_pedido BETWEEN data_inicio AND data_fim;

    INSERT INTO tmp_relatorio_vendas (tipo_linha, descricao, quantidade, valor)
    SELECT 
        'Resumo', 
        'Média Valor por Pedido', 
        NULL,
        COALESCE(AVG(p.vl_pedido), 0)
    FROM 
        pedido p
    WHERE 
        p.dt_pedido BETWEEN data_inicio AND data_fim;


    -- Inserir lista de produtos da categoria com quantidade vendida e status atual do pedido
    INSERT INTO tmp_relatorio_vendas (tipo_linha, descricao, quantidade, valor)
    SELECT
        'Produto',
        CONCAT('Produto: ', pr.nm_produto),
        SUM(ip.qt_produto) AS quantidade_vendida,
        COALESCE(SUM(pr.vl_produto), 0)
    FROM
        item_pedido ip
    JOIN pedido p ON ip.id_pedido = p.id_pedido
    JOIN produto pr ON ip.id_produto = pr.id_produto
    JOIN categoria_produto cp ON pr.id_categoria = cp.id_categoria
    WHERE
        p.dt_pedido BETWEEN data_inicio AND data_fim
        AND cp.nm_categoria = categoria_produto
    GROUP BY
        pr.nm_produto
    ORDER BY
        quantidade_vendida DESC;

    -- Retornar resultado consolidado
    SELECT 
        tipo_linha,
        descricao,
        quantidade,
        valor
    FROM tmp_relatorio_vendas;

    -- Limpar tabela temporária
    DROP TEMPORARY TABLE tmp_relatorio_vendas;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-22 22:14:04
